const initialState = {}

const mainReducer = (state = initialState, action) => {
    return state;
}


export default mainReducer